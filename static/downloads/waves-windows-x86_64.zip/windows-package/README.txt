WAVES Audio Player for Windows

Run install-windows.ps1 to install
