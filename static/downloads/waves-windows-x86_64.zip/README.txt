WAVES Music Player - Windows Installation

To install:
1. Right-click on install-windows.ps1
2. Select 'Run with PowerShell'

Or manually:
1. Copy waves.exe to a directory of your choice
2. Add that directory to your PATH
3. Run: waves.exe
