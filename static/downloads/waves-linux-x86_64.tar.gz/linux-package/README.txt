WAVES Music Player - Linux Installation

To install:
1. Run: chmod +x install-linux.sh
2. Run: ./install-linux.sh

Or manually:
1. Copy 'waves' to ~/.local/bin/
2. Make it executable: chmod +x ~/.local/bin/waves
3. Run: waves
